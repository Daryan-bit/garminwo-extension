'use strict';
const t = (key) => { try { return chrome.i18n.getMessage(key) || key; } catch(e) { return key; } };

document.getElementById('sub').textContent           = t('sub');
document.getElementById('api_key_label').textContent = t('api_key_label');
document.getElementById('save').textContent          = t('save_btn');
document.getElementById('credit_link').textContent   = t('credit_link');
document.getElementById('kofi-btn').textContent      = t('kofi_btn');
document.getElementById('kofi_sub').textContent      = t('kofi_sub');
document.getElementById('badge-free').textContent    = t('badge_free');
document.getElementById('badge-paid').textContent    = t('badge_paid');
document.getElementById('tip-gemini').innerHTML      = t('tip_gemini');
document.getElementById('tip-claude').innerHTML      = t('tip_claude');
document.getElementById('how_block').innerHTML =
  '<b>' + t('how_title') + '</b><br>' +
  '1. ' + t('how_1') + '<br>' +
  '2. ' + t('how_2') + '<br>' +
  '3. ' + t('how_3') + '<br>' +
  '4. ' + t('how_4');

const tabGemini = document.getElementById('tab-gemini');
const tabClaude = document.getElementById('tab-claude');
const secGemini = document.getElementById('section-gemini');
const secClaude = document.getElementById('section-claude');

function switchEngine(engine) {
  tabGemini.classList.toggle('active', engine === 'gemini');
  tabClaude.classList.toggle('active', engine === 'claude');
  secGemini.classList.toggle('active', engine === 'gemini');
  secClaude.classList.toggle('active', engine === 'claude');
  chrome.storage.local.set({ gwo_engine: engine });
}
tabGemini.addEventListener('click', () => switchEngine('gemini'));
tabClaude.addEventListener('click', () => switchEngine('claude'));

// Claude
const keyInput = document.getElementById('apiKey');
const saveBtn  = document.getElementById('save');
const status   = document.getElementById('status');
saveBtn.addEventListener('click', () => {
  const key = keyInput.value.trim();
  if (!key) { status.className='status err'; status.textContent=t('status_empty'); return; }
  chrome.storage.local.set({ gwo_api_key: key }, () => {
    status.className='status ok'; status.textContent=t('status_saved');
  });
});

// Gemini
const geminiInput   = document.getElementById('geminiKey');
const saveGeminiBtn = document.getElementById('save-gemini');
const statusGemini  = document.getElementById('status-gemini');
saveGeminiBtn.addEventListener('click', () => {
  const key = geminiInput.value.trim();
  if (!key) { statusGemini.className='status err'; statusGemini.textContent=t('status_empty'); return; }
  chrome.storage.local.set({ gwo_gemini_key: key }, () => {
    statusGemini.className='status ok'; statusGemini.textContent=t('status_saved');
  });
});

// Restaurer
chrome.storage.local.get(['gwo_api_key','gwo_gemini_key','gwo_engine'], (data) => {
  switchEngine(data.gwo_engine || 'gemini');
  if (data.gwo_api_key)    { keyInput.value=data.gwo_api_key; status.className='status ok'; status.textContent=t('status_ok'); }
  if (data.gwo_gemini_key) { geminiInput.value=data.gwo_gemini_key; statusGemini.className='status ok'; statusGemini.textContent=t('status_ok'); }
});
