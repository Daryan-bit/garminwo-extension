'use strict';

// Helper i18n — avec cache local pour résister au service worker endormi
const _i18nCache = {};
const t = (key) => {
  // Retourner depuis le cache si disponible
  if (_i18nCache[key]) return _i18nCache[key];
  try {
    const msg = chrome.runtime?.id ? chrome.i18n.getMessage(key) : '';
    if (msg) { _i18nCache[key] = msg; return msg; }
  } catch(e) {}
  // Fallback dictionnaire intégré (EN)
  const fallback = {
    modal_title: 'Import from image or JSON',
    modal_sub: 'Analyse a workout photo and import the session',
    drop_text: '<strong style="color:#00c9a7">Click or drop a file</strong><br>JPG, PNG — screenshot · Garmin JSON',
    analyze_btn: '🔍 Analyse session',
    analyzing: 'AI image analysis in progress...',
    seances_label: 'Sessions detected — select the one to import:',
    import_btn: '✅ Import into Garmin Connect',
    importing: 'Importing...',
    success_msg: 'Imported! Reloading...',
    clear_img: '✕ Change image',
    err_no_key: '⚠ Configure your API key in the extension',
    err_no_img: '⚠ Please select an image first',
    steps_count: 'steps',
    steps_detected: 'steps detected',
    err_unknown: 'Unknown error',
    err_no_api_key: '⚠ Missing API key',
    err_garmin: 'Garmin Connect error ($STATUS$)',
  };
  return fallback[key] || key;
};
if (!chrome.runtime?.id) { throw new Error('Extension context invalidated'); }

// ── Injection du bouton sur Garmin Connect ─────────────────────
(function init() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inject);
  } else {
    inject();
  }

  const checkUrl = () => {
    const btn = document.getElementById('gwo-btn');
    if (isWorkoutPage()) {
      if (!btn) inject();
      // Réinitialiser l'observer à chaque changement de page pour
      // réinjecter les checkboxes sur la nouvelle liste chargée
      if (gwoCheckboxObserver) {
        clearInterval(gwoCheckboxObserver);
        gwoCheckboxObserver = null;
      }
      injectCheckboxes();
    } else {
      if (btn) btn.remove();
      removeDeleteBar();
    }
  };

  // Intercepter pushState et replaceState
  const origPush    = history.pushState.bind(history);
  const origReplace = history.replaceState.bind(history);
  history.pushState    = (...a) => { origPush(...a);    checkUrl(); };
  history.replaceState = (...a) => { origReplace(...a); checkUrl(); };
  window.addEventListener('popstate', checkUrl);

  // Polling léger toutes les 500ms en fallback
  setInterval(checkUrl, 300);
})();

// Écouter le message depuis background.js (onglet déjà ouvert)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'GWO_OPEN_WITH_IMAGE') {
    checkPendingImage(true);
  }
  if (msg.type === 'GWO_OPEN_WITH_TEXT') {
    checkPendingText(true);
  }
});

function isWorkoutPage() {
  return location.href.includes('/workouts');
}

function inject() {
  if (document.getElementById('gwo-btn')) return;
  if (!isWorkoutPage()) return;

  // Chercher le bouton "Créer un entraînement" pour s'y coller
  const createBtn = Array.from(document.querySelectorAll('button')).find(b =>
    b.textContent.includes('Créer un entraînement') ||
	b.textContent.includes('Create a Workout') ||
    b.textContent.includes('Create Workout') ||
    b.textContent.includes('Crear entrenamiento')
  );
  
  // Si le bouton Garmin n'est pas encore là, on réessaie dans 500ms
  if (!createBtn) {
    setTimeout(inject, 500);
    return;
  }

  const btn = document.createElement('button');
  btn.id = 'gwo-btn';
  btn.innerHTML = '📸 ' + t('modal_title');

  if (createBtn && createBtn.parentNode) {
    // Insérer juste après le bouton Garmin
    btn.style.cssText = `
      margin-left: 10px;
      background: #00c9a7;
      color: #0d0f14;
      border: none;
      padding: 0 16px;
      height: ${createBtn.offsetHeight || 36}px;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 1px;
      cursor: pointer;
      font-family: inherit;
      transition: opacity 0.2s;
      white-space: nowrap;
    `;
    btn.addEventListener('mouseenter', () => btn.style.opacity = '0.85');
    btn.addEventListener('mouseleave', () => btn.style.opacity = '1');
    btn.addEventListener('click', openModal);
    createBtn.parentNode.insertBefore(btn, createBtn.nextSibling);
    // Vérifier si une image ou un texte est en attente (envoyé via clic droit)
    checkPendingImage();
    checkPendingText();
  } else {
    // Fallback : bouton flottant si le bouton Garmin n'est pas trouvé
    btn.style.cssText = `
      position: fixed; bottom: 24px; right: 24px; z-index: 99999;
      background: #00c9a7; color: #0d0f14; border: none;
      padding: 12px 22px; border-radius: 8px; font-size: 14px;
      font-weight: 700; letter-spacing: 1px; cursor: pointer;
      box-shadow: 0 4px 20px rgba(0,201,167,0.4); transition: all 0.2s;
      font-family: 'Segoe UI', sans-serif;
    `;
    btn.addEventListener('mouseenter', () => btn.style.transform = 'translateY(-2px)');
    btn.addEventListener('mouseleave', () => btn.style.transform = 'translateY(0)');
    btn.addEventListener('click', openModal);
    document.body.appendChild(btn);
    checkPendingImage();
    checkPendingText();
  }
}
// ── Modale ──────────────────────────────────────────────────────
function openModal() {
  if (document.getElementById('gwo-modal-overlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'gwo-modal-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0; background: rgba(0,0,0,0.75);
    z-index: 999999; display: flex; align-items: center; justify-content: center;
    font-family: 'Segoe UI', sans-serif;
  `;
  overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

  overlay.innerHTML = `
    <div id="gwo-modal" style="
      background: #1a1d24; border: 1px solid #2d3748; border-radius: 12px;
      padding: 32px; max-width: 520px; width: 92%; max-height: 90vh;
      overflow-y: auto; position: relative; color: #e5e7eb;
    ">
      <button id="gwo-close" style="
        position: absolute; top: 16px; right: 16px; background: none; border: none;
        color: #6b7280; font-size: 20px; cursor: pointer; line-height: 1;
      ">✕</button>
      <button id="gwo-help" style="
        position: absolute; top: 16px; right: 48px; background: none;
        border: 1px solid #2d3748; color: #6b7280; font-size: 12px; font-weight: 700;
        cursor: pointer; border-radius: 50%; width: 22px; height: 22px;
        text-align: center; line-height: 20px; transition: all 0.2s;
      " title="Help">?</button>


      <div style="font-size: 20px; font-weight: 900; letter-spacing: 3px;
                  text-transform: uppercase; color: #00c9a7; margin-bottom: 4px;">
        GarminWO
      </div>
      <div id="gwo-modal-sub" style="font-size: 12px; color: #6b7280; margin-bottom: 16px;"></div>
      <div style="font-size: 10px; color: #4b5563; margin-bottom: 16px;">
        🐛 Report a bug: <a href="mailto:yannick.darlavoix@gmail.com" style="color:#00c9a7; text-decoration:none;">yannick.darlavoix@gmail.com</a>
      </div>

      <!-- Zone drop -->
      <div id="gwo-drop" style="
        border: 2px dashed #2d3748; border-radius: 8px; padding: 32px;
        text-align: center; cursor: pointer; transition: all 0.2s; margin-bottom: 16px;
      ">
        <div style="font-size: 36px; margin-bottom: 8px;">🖼️</div>
        <div style="font-size: 13px; color: #9ca3af;">
          <span id="gwo-drop-text"></span>
        </div>
      </div>
      <input type="file" id="gwo-file" accept="image/*,.json" style="display:none">
      <img id="gwo-preview" style="display:none; max-width:100%; border-radius:6px; margin-bottom:14px; border:1px solid #2d3748;">

	<div id="gwo-clear-img" style="display:none; margin-bottom:10px;">
	  <button id="gwo-clear-img-btn" style="
		background:white; border:1px solid #ef4444; color:#ef4444;
		border-radius:6px; padding:6px 14px; font-size:11px;
		letter-spacing:2px; text-transform:uppercase; cursor:pointer; font-weight:600;
	  "></button>
	</div>
     
	 <!-- Section analyse -->
      <div id="gwo-analyze-section" style="display:none;">
        <button id="gwo-analyze-btn" style="
          width: 100%; background: #00c9a7; color: #0d0f14; border: none;
          padding: 13px; border-radius: 8px; font-size: 14px; font-weight: 700;
          letter-spacing: 2px; text-transform: uppercase; cursor: pointer; margin-bottom: 8px;
        "></button>
      </div>

      <!-- Chargement -->
      <div id="gwo-loading" style="display:none; text-align:center; padding: 20px; color: #6b7280;">
        <div id="gwo-spinner" style="
          display: inline-block; width: 28px; height: 28px;
          border: 3px solid #2d3748; border-top-color: #00c9a7;
          border-radius: 50%; animation: gwo-spin 0.8s linear infinite; margin-bottom: 8px;
        "></div>
        <div id="gwo-loading-text" style="font-size: 13px;"></div>
      </div>

      <!-- Résultats -->
      <div id="gwo-results" style="display:none;">
        <div style="font-size: 12px; color: #6b7280; margin-bottom: 10px;">
          <span id="gwo-seances-label"></span>
        </div>
        <div id="gwo-seance-info" style="
          background: #0d0f14; border: 1px solid #2d3748; border-radius: 8px;
          padding: 14px; margin-bottom: 14px;
        "></div>
        <button id="gwo-import-btn" style="
          width: 100%; background: #00c9a7; color: #0d0f14; border: none;
          padding: 13px; border-radius: 8px; font-size: 14px; font-weight: 700;
          letter-spacing: 2px; text-transform: uppercase; cursor: pointer;
        "></button>
      </div>

      <!-- Erreur -->
      <div id="gwo-error" style="display:none;
        background: rgba(255,107,53,0.1); color: #ff6b35; border-radius: 6px;
        padding: 10px 12px; font-size: 12px; margin-top: 8px;
      ">
        <span id="gwo-error-msg"></span>
        <button id="gwo-retry-btn" style="
          display:none; margin-top:8px; width:100%;
          background:none; border:1px solid #ff6b35; color:#ff6b35;
          border-radius:5px; padding:6px; font-size:11px; font-weight:700;
          letter-spacing:1px; text-transform:uppercase; cursor:pointer;
          transition: all 0.2s;
        ">🔄 Réessayer</button>
        <button id="gwo-switch-engine-btn" style="
          display:none; margin-top:6px; width:100%;
          background:none; border:1px solid #00c9a7; color:#00c9a7;
          border-radius:5px; padding:6px; font-size:11px; font-weight:700;
          letter-spacing:1px; text-transform:uppercase; cursor:pointer;
          transition: all 0.2s;
        "></button>
      </div>

      <!-- Succès -->
      <div id="gwo-success" style="display:none;
        background: rgba(0,201,167,0.1); color: #00c9a7; border-radius: 6px;
        padding: 10px 12px; font-size: 12px; margin-top: 8px; text-align: center;
      "></div>
    </div>
    <style>
      @keyframes gwo-spin { to { transform: rotate(360deg); } }
      #gwo-drop:hover { border-color: #00c9a7 !important; background: rgba(0,201,167,0.05); }
      #gwo-drop.dragover { border-color: #00c9a7 !important; background: rgba(0,201,167,0.08); }
      #gwo-analyze-btn:hover, #gwo-import-btn:hover { opacity: 0.85; }
      #gwo-analyze-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    </style>
  `;

  document.body.appendChild(overlay);

  // Événements
  document.getElementById('gwo-close').addEventListener('click', closeModal);
  const helpBtn = document.getElementById('gwo-help');
  if (helpBtn) {
    helpBtn.addEventListener('click', openHelpPdf);
    helpBtn.addEventListener('mouseenter', () => { helpBtn.style.borderColor = '#00c9a7'; helpBtn.style.color = '#00c9a7'; });
    helpBtn.addEventListener('mouseleave', () => { helpBtn.style.borderColor = '#2d3748'; helpBtn.style.color = '#6b7280'; });
  }


  // Appliquer les traductions
  const modalSub = document.getElementById('gwo-modal-sub');
  if (modalSub) modalSub.textContent = t('modal_sub');
  const dropText = document.getElementById('gwo-drop-text');
  if (dropText) dropText.innerHTML = t('drop_text');
  const loadingText = document.getElementById('gwo-loading-text');
  if (loadingText) loadingText.textContent = t('analyzing');
  const seancesLabel = document.getElementById('gwo-seances-label');
  if (seancesLabel) seancesLabel.textContent = t('seances_label');
  const clearImgBtn = document.getElementById('gwo-clear-img-btn');
  if (clearImgBtn) clearImgBtn.textContent = t('clear_img');
  const analyzeBtn = document.getElementById('gwo-analyze-btn');
  if (analyzeBtn) analyzeBtn.textContent = t('analyze_btn');
  const importBtn = document.getElementById('gwo-import-btn');
  if (importBtn) importBtn.textContent = t('import_btn');


  const drop  = document.getElementById('gwo-drop');
  const input = document.getElementById('gwo-file');

  drop.addEventListener('click', () => input.click());
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('dragover'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', e => {
    e.preventDefault(); drop.classList.remove('dragover');
    if (e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0]);
  });
  input.addEventListener('change', () => { if (input.files[0]) loadFile(input.files[0]); });

  document.getElementById('gwo-analyze-btn').addEventListener('click', analyzeImage);
  document.getElementById('gwo-import-btn').addEventListener('click', importWorkout);
  document.getElementById('gwo-clear-img-btn').addEventListener('click', clearImage);
  const switchEngineBtn = document.getElementById('gwo-switch-engine-btn');
  if (switchEngineBtn) {
    switchEngineBtn.addEventListener('click', () => {
      // Basculer vers l'autre moteur et relancer
      getApiKey().then(({ key, engine }) => {
        const newEngine = engine === 'gemini' ? 'claude' : 'gemini';
        chrome.storage.local.set({ gwo_engine: newEngine }, () => {
          document.getElementById('gwo-error').style.display = 'none';
          document.getElementById('gwo-switch-engine-btn').style.display = 'none';
          document.getElementById('gwo-retry-btn').style.display = 'none';
          // Relancer l'analyse avec le nouveau moteur
          if (currentImageBase64) {
            analyzeImage();
          } else if (currentPendingText) {
            retryTextAnalysis();
          }
        });
      });
    });
    switchEngineBtn.addEventListener('mouseenter', () => { switchEngineBtn.style.background = 'rgba(0,201,167,0.1)'; });
    switchEngineBtn.addEventListener('mouseleave', () => { switchEngineBtn.style.background = 'none'; });
  }

  document.getElementById('gwo-retry-btn').addEventListener('click', () => {
    document.getElementById('gwo-error').style.display = 'none';
    if (currentImageBase64) {
      // Retry analyse image
      analyzeImage();
    } else if (currentPendingText) {
      // Retry analyse texte — renvoyer directement à l'IA
      retryTextAnalysis();
    } else if (currentSeance) {
      // Retry import (séance déjà parsée mais import échoué)
      importWorkout();
    }
  });
  // Hover sur le bouton retry
  const retryBtn = document.getElementById('gwo-retry-btn');
  if (retryBtn) {
    retryBtn.addEventListener('mouseenter', () => { retryBtn.style.background = 'rgba(255,107,53,0.15)'; });
    retryBtn.addEventListener('mouseleave', () => { retryBtn.style.background = 'none'; });
  }
}

function closeModal() {
  const overlay = document.getElementById('gwo-modal-overlay');
  if (overlay) overlay.remove();
}

let currentImageBase64 = null;
let currentImageMime   = 'image/jpeg';
let currentSeance      = null;
let currentSeances     = [];
let currentPendingText = null;  // texte en attente de retry

function loadFile(file) {
  if (file.type === 'application/json' || file.name.endsWith('.json')) {
    // Traitement direct JSON
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const json = JSON.parse(e.target.result);
        currentSeance = {
		  nom: json.workoutName || 'Import JSON',
		  description: json.description || '',
		  steps: extractStepsFromGarminJson(json),
		  _rawJson: json
		};
        currentSeances = [currentSeance];
        // Afficher directement les résultats sans analyse
        const info = document.getElementById('gwo-seance-info');
        info.innerHTML = `
          <div style="border:2px solid #00c9a7;background:rgba(0,201,167,.08);border-radius:6px;padding:10px 12px;">
            <div style="font-weight:700;font-size:13px;color:#00c9a7;">${json.workoutName || 'Import JSON'}</div>
            <div style="font-size:11px;color:#9ca3af;margin-top:3px;">${json.description || ''}</div>
            <div style="font-size:10px;color:#6b7280;margin-top:3px;">${countSteps(currentSeance.steps||[])} ${t('steps_detected')}</div>
          </div>`;
        document.getElementById('gwo-drop').style.display = 'none';
        document.getElementById('gwo-clear-img').style.display = 'block';
        document.getElementById('gwo-analyze-section').style.display = 'none';
        document.getElementById('gwo-results').style.display = 'block';
        document.getElementById('gwo-error').style.display = 'none';
      } catch(e) {
        showError('⚠ JSON invalide : ' + e.message);
      }
    };
    reader.readAsText(file);
  } else {
    // Traitement image existant
    currentImageMime = file.type || 'image/jpeg';
    const reader = new FileReader();
    reader.onload = e => {
      currentImageBase64 = e.target.result.split(',')[1];
      const preview = document.getElementById('gwo-preview');
      preview.src = e.target.result;
      preview.style.display = 'block';
      document.getElementById('gwo-analyze-section').style.display = 'block';
      document.getElementById('gwo-results').style.display = 'none';
      document.getElementById('gwo-error').style.display = 'none';
      document.getElementById('gwo-success').style.display = 'none';
      document.getElementById('gwo-drop').style.display = 'none';
      document.getElementById('gwo-clear-img').style.display = 'block';
    };
    reader.readAsDataURL(file);
  }
}

function extractStepsFromGarminJson(json) {
  try {
    return json.workoutSegments?.[0]?.workoutSteps || [];
  } catch(e) { return []; }
}

function clearImage() {
  currentImageBase64 = null;
  const preview = document.getElementById('gwo-preview');
  preview.src = '';
  preview.style.display = 'none';
  document.getElementById('gwo-analyze-section').style.display = 'none';
  document.getElementById('gwo-results').style.display = 'none';
  document.getElementById('gwo-error').style.display = 'none';
  document.getElementById('gwo-success').style.display = 'none';
  document.getElementById('gwo-drop').style.display = 'block';
  document.getElementById('gwo-clear-img').style.display = 'none';
  document.getElementById('gwo-file').value = '';
}

async function analyzeImage() {
  const { key: apiKey, engine } = await getApiKey();
  if (!apiKey) {
    showError(t('err_no_key'));
    return;
  }
  if (!currentImageBase64) {
    showError(t('err_no_img'));
    return;
  }

  const btn = document.getElementById('gwo-analyze-btn');
  btn.disabled = true;
  document.getElementById('gwo-loading').style.display = 'block';
  document.getElementById('gwo-results').style.display = 'none';
  document.getElementById('gwo-error').style.display = 'none';

  chrome.runtime.sendMessage(
    { type: 'ANALYZE_IMAGE', apiKey, engine, imageBase64: currentImageBase64, imageMime: currentImageMime },
    response => {
      btn.disabled = false;
      document.getElementById('gwo-loading').style.display = 'none';

      if (!response || !response.success) {
        showError('⚠ ' + (response?.error || t('err_unknown')), true);
        return;
      }

const seances = response.data.seances;
currentSeances = seances;
currentSeance = seances[0];

// Afficher toutes les séances
const info = document.getElementById('gwo-seance-info');
info.innerHTML = seances.map((s, i) => `
  <div id="gwo-s-${i}" style="
    padding:10px 12px; border-radius:6px; cursor:pointer; margin-bottom:6px;
    border: 2px solid ${i===0 ? '#00c9a7' : '#2d3748'};
    background: ${i===0 ? 'rgba(0,201,167,0.08)' : 'transparent'};
  ">
    <div style="font-weight:700; font-size:13px; color:#00c9a7;">${s.nom || 'Séance '+(i+1)}</div>
    <div style="font-size:11px; color:#9ca3af; margin-top:3px;">${s.description || ''}</div>
    <div style="font-size:10px; color:#6b7280; margin-top:3px;">${countSteps(s.steps||[])} ${t('steps_count')}</div>
  </div>
`).join('');
// Ajouter les clics via addEventListener (CSP safe)
seances.forEach((_, i) => {
  const el = document.getElementById('gwo-s-'+i);
  if (el) el.addEventListener('click', () => {
    currentSeance = currentSeances[i];
    currentSeances.forEach((__, j) => {
      const ej = document.getElementById('gwo-s-'+j);
      if (ej) {
        ej.style.border = j===i ? '2px solid #00c9a7' : '2px solid #2d3748';
        ej.style.background = j===i ? 'rgba(0,201,167,0.08)' : 'transparent';
      }
    });
  });
});
document.getElementById('gwo-results').style.display = 'block';
    }
  );
}

function countSteps(steps) {
  let count = 0;
  for (const s of steps) {
    if (s.type === 'repeat') count += countSteps(s.steps || []);
    else count++;
  }
  return count;
}

async function importWorkout() {
  if (!currentSeance) return;

  const { key: apiKey, engine } = await getApiKey();
  if (!apiKey) { showError(t('err_no_key')); return; }

  const btn = document.getElementById('gwo-import-btn');
  btn.disabled = true;
  btn.textContent = t('importing');
  document.getElementById('gwo-error').style.display = 'none';

  try {
    // Si la séance vient d'un JSON Garmin direct, on l'envoie tel quel
	const workoutJson = currentSeance._rawJson 
	  ? currentSeance._rawJson 
	  : buildGarminJson(currentSeance);

    // Utiliser le cookie de session Garmin Connect existant
    // Lire le token CSRF depuis les cookies
	const csrfToken = document.cookie.split(';')
	  .map(c => c.trim())
	  .find(c => c.startsWith('connect-csrf-token') || c.startsWith('SESSIONID'));

	// Lire le token CSRF depuis le meta tag ou le store Garmin
	const csrf = document.querySelector('meta[name="csrf-token"]')?.content ||
	  (window.__garmin?.csrfToken) ||
	  document.cookie.match(/connect-csrf-token=([^;]+)/)?.[1] || '';
	console.log('JSON envoyé:', JSON.stringify(workoutJson, null, 2));
	const resp = await fetch('https://connect.garmin.com/gc-api/workout-service/workout', {
	  method: 'POST',
	  headers: {
		'Content-Type': 'application/json',
		'NK': 'NT',
		'X-app-ver': '5.23.0.33',
		'connect-csrf-token': csrf,
		'x-requested-with': 'XMLHttpRequest'
	  },
	  credentials: 'include',
	  body: JSON.stringify(workoutJson)
	});

   if (!resp.ok) {
	  const err = await resp.text();
	  console.log('Réponse Garmin:', err);
	  throw new Error(t('err_garmin').replace('$STATUS$', resp.status) + ': ' + err);
	}
    // Garmin retourne souvent un body vide — lire l'ID depuis le header Location
    const locationHeader = resp.headers.get('Location') || '';
    const headerMatch = locationHeader.match(/\/workout\/(\d+)/);

    let workoutId = null;
    if (headerMatch) {
      workoutId = headerMatch[1];
    } else {
      try {
        const text = await resp.clone().text();
        if (text && text !== 'null') {
          const result = JSON.parse(text);
          workoutId = result?.workoutId || result?.workout?.workoutId || null;
          console.log('GWO result:', JSON.stringify(result));
        }
      } catch(e) {}
    }
    console.log('GWO workoutId:', workoutId, '| Location:', locationHeader);

    document.getElementById('gwo-success').style.display = 'block';
    document.getElementById('gwo-success').textContent =
      t('success_msg').replace ? t('success_msg') : t('success_msg');
    document.getElementById('gwo-results').style.display = 'none';

    // Chercher l'ID dans le cache par nom de séance
    const importedName = currentSeance?.nom || null;
    console.log('GWO import redirect - nom:', importedName);

    // Recharger le cache pour avoir l'ID de la séance fraîchement créée
    gwoWorkoutCacheLoaded = false;
    gwoWorkoutCacheLoading = false;
    setTimeout(() => {
      loadWorkoutIds().then(() => {
        const freshId = importedName ? gwoWorkoutCache[importedName] : null;
        console.log('GWO freshId:', freshId, 'pour', importedName);
        window.location.href = freshId
          ? `https://connect.garmin.com/app/workout/${freshId}?workoutType=running`
          : 'https://connect.garmin.com/app/workouts';
      });
    }, 2000);

  } catch (e) {
    showError('⚠ ' + e.message, true);
    btn.disabled = false;
    btn.textContent = t('import_btn');
  }
}

function buildGarminJson(seance) {
  const ctx = { counter: 0 };
  const steps = buildSteps(seance.steps || [], ctx);
  return {
    workoutName: seance.nom || 'GarminWO Import',
    sportType: { sportTypeId: 1, sportTypeKey: 'running', displayOrder: 1 },
    subSportType: null,
    estimatedDistanceUnit: { unitKey: null },
    estimatedDurationInSecs: 0,
    estimatedDistanceInMeters: 0,
    estimateType: null,
    isWheelchair: false,
    workoutSegments: [{
      segmentOrder: 1,
      sportType: { sportTypeId: 1, sportTypeKey: 'running', displayOrder: 1 },
      workoutSteps: steps
    }]
  };
}

const STEP_TYPES = {
  warmup:   { stepTypeId: 1, stepTypeKey: 'warmup',   displayOrder: 1 },
  cooldown: { stepTypeId: 2, stepTypeKey: 'cooldown',  displayOrder: 2 },
  interval: { stepTypeId: 3, stepTypeKey: 'interval',  displayOrder: 3 },
  recovery: { stepTypeId: 4, stepTypeKey: 'recovery',  displayOrder: 4 },
  repeat:   { stepTypeId: 6, stepTypeKey: 'repeat',    displayOrder: 6 },
};

const COND_TYPES = {
  'lap':        { conditionTypeId: 1, conditionTypeKey: 'lap.button', displayOrder: 1, displayable: true },
  'lap.button': { conditionTypeId: 1, conditionTypeKey: 'lap.button', displayOrder: 1, displayable: true },
  'distance':   { conditionTypeId: 3, conditionTypeKey: 'distance',   displayOrder: 3, displayable: true },
  'time':       { conditionTypeId: 2, conditionTypeKey: 'time', displayOrder: 2, displayable: true },
  'fixed.time': { conditionTypeId: 2, conditionTypeKey: 'time', displayOrder: 2, displayable: true },
  'iterations': { conditionTypeId: 7, conditionTypeKey: 'iterations', displayOrder: 7, displayable: false },
};

function buildSteps(steps, ctx) {
  const result = [];
  for (const s of steps) {
    ctx.counter++;
    const myId = ctx.counter;
    if (s.type === 'repeat') {
      const subSteps = buildSteps(s.steps || [], ctx);
      result.push({
      stepId: myId,
      stepOrder: myId,
      type: 'RepeatGroupDTO',
      stepType: STEP_TYPES.repeat,
      endCondition: COND_TYPES['iterations'],
      endConditionValue: s.iterations || 2,
      numberOfIterations: s.iterations || 2,
      workoutSteps: subSteps
	});
    } else {
      const condType = s.condType || 'lap.button';
      const endCond  = COND_TYPES[condType] || COND_TYPES['lap.button'];
      let endValue = 1000;
      if (condType === 'distance') {
        const raw = parseFloat(s.cv) || 0;
        endValue = s.cvUnit === 'km' ? raw * 1000 : raw;
      }  else if (condType === 'time' || condType === 'fixed.time') {
		  const raw = parseFloat(s.cv || s.endConditionValue) || 0;
		  endValue = raw > 300 ? raw : raw * 60;
		}
      const step = {
        stepId: myId,
        stepOrder: myId,
        type: 'ExecutableStepDTO',
        stepType: STEP_TYPES[s.type] || STEP_TYPES.interval,
        endCondition: endCond,
        endConditionValue: endValue,
        description: s.desc || null,
        category: null,
        exerciseName: null
      };
      if (s.t1 || s.t2) {
        step.targetType = { workoutTargetTypeId: 6, workoutTargetTypeKey: 'pace.zone', displayOrder: 6 };
        step.targetValueOne  = paceToMs(s.t1 || s.t2);
        step.targetValueTwo  = paceToMs(s.t2 || s.t1);
      } else {
        step.targetType = { workoutTargetTypeId: 1, workoutTargetTypeKey: 'no.target', displayOrder: 1 };
      }
      result.push(step);
    }
  }
  return result;
}

function paceToMs(pace) {
  if (!pace || typeof pace !== 'string') return null;
  const m = pace.match(/(\d+)'(\d+)/);
  if (!m) return null;
  const secs = parseInt(m[1]) * 60 + parseInt(m[2]);
  return secs > 0 ? Math.round(1000 / secs * 1000) / 1000 : null;
}

function getApiKey() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get(['gwo_api_key','gwo_gemini_key','gwo_engine'], d => {
        if (chrome.runtime.lastError) { resolve({ key: null, engine: 'gemini' }); return; }
        const engine = d.gwo_engine || 'gemini';
        const key = engine === 'gemini' ? (d.gwo_gemini_key||null) : (d.gwo_api_key||null);
        resolve({ key, engine });
      });
    } catch(e) {
      // Extension context invalidated — onglet à recharger
      resolve({ key: null, engine: 'gemini' });
    }
  });
}

function showError(msg, showRetry = false) {
  const el            = document.getElementById('gwo-error');
  const msgEl         = document.getElementById('gwo-error-msg');
  const retryBtn      = document.getElementById('gwo-retry-btn');
  const switchBtn     = document.getElementById('gwo-switch-engine-btn');
  if (!el) return;
  el.style.display = 'block';
  if (msgEl) msgEl.textContent = msg;
  if (retryBtn) retryBtn.style.display = showRetry ? 'block' : 'none';

  // Afficher le bouton de bascule si c'est une erreur de quota
  if (switchBtn) {
    const isQuota = msg.includes('Quota') || msg.includes('quota') || msg.includes('exceeded');
    if (isQuota && showRetry) {
      getApiKey().then(({ engine }) => {
        const otherEngine = engine === 'gemini' ? 'Claude' : 'Gemini';
        const otherKey = engine === 'gemini' ? 'gwo_api_key' : 'gwo_gemini_key';
        // Vérifier que l'autre moteur a une clé configurée
        chrome.storage.local.get([otherKey], d => {
          if (d[otherKey]) {
            switchBtn.textContent = `⚡ Réessayer avec ${otherEngine}`;
            switchBtn.style.display = 'block';
          } else {
            switchBtn.style.display = 'none';
          }
        });
      });
    } else {
      switchBtn.style.display = 'none';
    }
  }
}

function openHelpPdf() {
  const lang = chrome.i18n.getUILanguage().substring(0, 2).toLowerCase();
  const available = ['fr', 'en', 'es', 'de', 'it', 'ru'];
  const locale = available.includes(lang) ? lang.toUpperCase() : 'EN';
  const pdfUrl = chrome.runtime.getURL('help/GarminWO_Help_' + locale + '.pdf');
  window.open(pdfUrl, '_blank');
}

// ── Image en attente (envoyée via clic droit) ──────────────────
function checkPendingImage(forceOpen = false) {
  try {
  chrome.runtime.sendMessage({ type: 'GWO_GET_PENDING' }, (resp) => {
    if (chrome.runtime.lastError) return;
    if (!resp || !resp.image) return;
    const { base64, mime } = resp.image;
    // Ouvrir le modal si pas déjà ouvert
    if (!document.getElementById('gwo-modal-overlay')) openModal();
    // Attendre que le modal soit dans le DOM
    const wait = setInterval(() => {
      const drop = document.getElementById('gwo-drop');
      if (!drop) return;
      clearInterval(wait);
      // Injecter l'image comme si l'utilisateur l'avait déposée
      currentImageBase64 = base64;
      currentImageMime   = mime;
      // Construire une data URL pour la preview
      const preview = document.getElementById('gwo-preview');
      if (preview) {
        preview.src = `data:${mime};base64,${base64}`;
        preview.style.display = 'block';
      }
      document.getElementById('gwo-drop').style.display          = 'none';
      document.getElementById('gwo-clear-img').style.display     = 'block';
      document.getElementById('gwo-analyze-section').style.display = 'block';
      document.getElementById('gwo-results').style.display       = 'none';
      document.getElementById('gwo-error').style.display         = 'none';
      document.getElementById('gwo-success').style.display       = 'none';
    }, 80);
  });
  } catch(e) { /* service worker endormi */ }
}

// ── Texte en attente (envoyé via clic droit sélection) ─────────
function checkPendingText(forceOpen = false) {
  try {
  chrome.runtime.sendMessage({ type: 'GWO_GET_PENDING_TEXT' }, (resp) => {
    if (chrome.runtime.lastError) return;
    if (!resp || !resp.text) return;
    const text = resp.text;
    currentPendingText = text;  // mémoriser pour le retry

    // Ouvrir le modal si pas déjà ouvert
    if (!document.getElementById('gwo-modal-overlay')) openModal();

    const wait = setInterval(() => {
      const drop = document.getElementById('gwo-drop');
      if (!drop) return;
      clearInterval(wait);

      // Récupérer la clé API et lancer l'analyse directement
      getApiKey().then(({ key: apiKey, engine }) => {
        if (!apiKey) {
          showError(t('err_no_key'));
          return;
        }

        // Masquer drop, montrer loading
        document.getElementById('gwo-drop').style.display          = 'none';
        document.getElementById('gwo-clear-img').style.display     = 'none';
        document.getElementById('gwo-analyze-section').style.display = 'none';
        document.getElementById('gwo-loading').style.display       = 'block';
        document.getElementById('gwo-results').style.display       = 'none';
        document.getElementById('gwo-error').style.display         = 'none';
        const _lElT = document.getElementById('gwo-loading-text');
        if (_lElT) _lElT.textContent = `🔍 Analyse par ${engine === 'gemini' ? 'Gemini' : 'Claude'} en cours...`;

        // Afficher un aperçu du texte dans la zone drop (avant analyse)
        const dropText = document.getElementById('gwo-drop-text');
        if (dropText) {
          drop.style.display = 'block';
          drop.style.cursor  = 'default';
          dropText.innerHTML = '<span style="font-size:11px;color:#9ca3af;white-space:pre-wrap;text-align:left;display:block;max-height:80px;overflow:hidden;">'
            + text.substring(0, 300).replace(/</g,'&lt;').replace(/>/g,'&gt;')
            + (text.length > 300 ? '…' : '')
            + '</span>';
        }
        document.getElementById('gwo-loading').style.display = 'block';

        // Envoyer à background pour analyse
        chrome.runtime.sendMessage(
          { type: 'ANALYZE_TEXT', apiKey, engine, text },
          response => {
            document.getElementById('gwo-loading').style.display = 'none';

            if (!response || !response.success) {
              showError('⚠ ' + (response?.error || t('err_unknown')), true);
              return;
            }

            const seances = response.data.seances;
            currentSeances = seances;
            currentSeance  = seances[0];

            const info = document.getElementById('gwo-seance-info');
            info.innerHTML = seances.map((s, i) => `
              <div id="gwo-s-${i}" style="
                padding:10px 12px; border-radius:6px; cursor:pointer; margin-bottom:6px;
                border: 2px solid ${i===0 ? '#00c9a7' : '#2d3748'};
                background: ${i===0 ? 'rgba(0,201,167,0.08)' : 'transparent'};
              ">
                <div style="font-weight:700; font-size:13px; color:#00c9a7;">${s.nom || 'Séance '+(i+1)}</div>
                <div style="font-size:11px; color:#9ca3af; margin-top:3px;">${s.description || ''}</div>
                <div style="font-size:10px; color:#6b7280; margin-top:3px;">${countSteps(s.steps||[])} ${t('steps_count')}</div>
              </div>`).join('');

            seances.forEach((_, i) => {
              const el = document.getElementById('gwo-s-'+i);
              if (el) el.addEventListener('click', () => {
                currentSeance = currentSeances[i];
                currentSeances.forEach((__, j) => {
                  const ej = document.getElementById('gwo-s-'+j);
                  if (ej) {
                    ej.style.border     = j===i ? '2px solid #00c9a7' : '2px solid #2d3748';
                    ej.style.background = j===i ? 'rgba(0,201,167,0.08)' : 'transparent';
                  }
                });
              });
            });

            document.getElementById('gwo-results').style.display = 'block';
          }
        );
      });
    }, 80);
  });
  } catch(e) { /* service worker endormi */ }
}

// ── Retry analyse texte ─────────────────────────────────────────
function retryTextAnalysis() {
  const text = currentPendingText;
  if (!text) return;

  getApiKey().then(({ key: apiKey, engine }) => {
    if (!apiKey) { showError(t('err_no_key')); return; }

    document.getElementById('gwo-loading').style.display  = 'block';
    document.getElementById('gwo-results').style.display  = 'none';
    document.getElementById('gwo-error').style.display    = 'none';
    const _lElR = document.getElementById('gwo-loading-text');
    if (_lElR) _lElR.textContent = `🔍 Analyse par ${engine === 'gemini' ? 'Gemini' : 'Claude'} en cours...`;

    chrome.runtime.sendMessage(
      { type: 'ANALYZE_TEXT', apiKey, engine, text },
      response => {
        document.getElementById('gwo-loading').style.display = 'none';

        if (!response || !response.success) {
          showError('⚠ ' + (response?.error || t('err_unknown')), true);
          return;
        }

        const seances = response.data.seances;
        currentSeances = seances;
        currentSeance  = seances[0];
        currentPendingText = null;  // nettoyage après succès

        const info = document.getElementById('gwo-seance-info');
        info.innerHTML = seances.map((s, i) => `
          <div id="gwo-s-${i}" style="
            padding:10px 12px; border-radius:6px; cursor:pointer; margin-bottom:6px;
            border: 2px solid ${i===0 ? '#00c9a7' : '#2d3748'};
            background: ${i===0 ? 'rgba(0,201,167,0.08)' : 'transparent'};
          ">
            <div style="font-weight:700; font-size:13px; color:#00c9a7;">${s.nom || 'Séance '+(i+1)}</div>
            <div style="font-size:11px; color:#9ca3af; margin-top:3px;">${s.description || ''}</div>
            <div style="font-size:10px; color:#6b7280; margin-top:3px;">${countSteps(s.steps||[])} ${t('steps_count')}</div>
          </div>`).join('');

        seances.forEach((_, i) => {
          const el = document.getElementById('gwo-s-'+i);
          if (el) el.addEventListener('click', () => {
            currentSeance = currentSeances[i];
            currentSeances.forEach((__, j) => {
              const ej = document.getElementById('gwo-s-'+j);
              if (ej) {
                ej.style.border     = j===i ? '2px solid #00c9a7' : '2px solid #2d3748';
                ej.style.background = j===i ? 'rgba(0,201,167,0.08)' : 'transparent';
              }
            });
          });
        });

        document.getElementById('gwo-results').style.display = 'block';
      }
    );
  });
}

// ════════════════════════════════════════════════════════════════
// SUPPRESSION MULTIPLE — Checkboxes injectées dans la liste native
// ════════════════════════════════════════════════════════════════

let gwoSelectedIds = new Set();
let gwoCheckboxObserver = null;
let gwoWorkoutCache = {}; // { nom → id }
let gwoWorkoutCacheLoaded = false;

let gwoWorkoutCacheLoading = false;
async function loadWorkoutIds() {
  if (gwoWorkoutCacheLoaded || gwoWorkoutCacheLoading) return;
  gwoWorkoutCacheLoading = true;
  try {
    // CSRF token dans le meta tag (pas dans les cookies depuis v5.24)
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content ||
                 document.cookie.match(/connect-csrf-token=([^;]+)/)?.[1] || '';
    const resp = await fetch(
      '/gc-api/workout-service/workouts?start=1&limit=999&myWorkoutsOnly=true&orderBy=UPDATE_DATE&orderSeq=DESC',
      { credentials: 'include', headers: { 'NK': 'NT', 'X-app-ver': '5.24.0.21', 'connect-csrf-token': csrf } }
    );
    console.log('GWO fetch status:', resp.status);
    if (!resp.ok) { console.log('GWO fetch failed:', resp.status); return; }
    const data = await resp.json();
    const list = data?.workouts || data?.results || (Array.isArray(data) ? data : []);
    list.forEach(w => {
      if (w.workoutName && w.workoutId) {
        const id = String(w.workoutId);
        if (!gwoWorkoutCache[w.workoutName]) {
          gwoWorkoutCache[w.workoutName] = [id];
        } else if (!gwoWorkoutCache[w.workoutName].includes(id)) {
          gwoWorkoutCache[w.workoutName].push(id);
        }
      }
    });
    gwoWorkoutCacheLoaded = true;
    gwoWorkoutCacheLoading = false;
    console.log('GWO cache chargé:', Object.keys(gwoWorkoutCache).length, 'entraînements');
  } catch(e) { console.log('GWO loadWorkoutIds error:', e); gwoWorkoutCacheLoading = false; }
}

function removeDeleteBar() {
  const bar = document.getElementById('gwo-delete-bar');
  if (bar) bar.remove();
  gwoSelectedIds.clear();
  if (gwoCheckboxObserver) {
    clearInterval(gwoCheckboxObserver);
    gwoCheckboxObserver = null;
  }
}

function injectCheckboxes() {
  // Observer les mutations pour réagir aux rechargements de la liste
  if (gwoCheckboxObserver) return;

  // Attendre que la table soit présente dans le DOM
  const waitForTable = (attempts = 0) => {
    const rows = Array.from(document.querySelectorAll('tr')).filter(r =>
      r.className && r.className.includes('tableRow') && !r.className.includes('tableHeader'));
    if (rows.length > 0) {
      // Charger le cache puis injecter — polling simple sans MutationObserver
      loadWorkoutIds().then(() => {
        renderCheckboxes();
        // Polling toutes les 2s pour détecter les nouvelles lignes (pagination etc.)
        gwoCheckboxObserver = setInterval(() => {
          const hasNew = Array.from(document.querySelectorAll('tr')).some(r =>
            r.className && r.className.includes('tableRow') &&
            !r.className.includes('tableHeader') &&
            !r.querySelector('.gwo-checkbox-cell')
          );
          if (hasNew) renderCheckboxes();
        }, 2000);
      });
    } else if (attempts < 20) {
      // Réessayer toutes les 300ms pendant 6 secondes max
      setTimeout(() => waitForTable(attempts + 1), 300);
    }
  };
  waitForTable();
}

function renderCheckboxes() {

  const rows = Array.from(document.querySelectorAll('tr')).filter(r =>
    r.className && r.className.includes('tableRow') && !r.className.includes('tableHeader'));
  rows.forEach(row => {
    if (row.querySelector('.gwo-checkbox-cell')) return; // déjà injecté

    // Extraire le nom de l'entraînement depuis le bouton
    const nameBtn = row.querySelector('[class*="workoutName"] button, [class*="workoutName"] a');
    const workoutName = nameBtn?.textContent?.trim();
    // Chercher l'ID dans le cache — gérer les doublons de noms
    const ids = workoutName ? gwoWorkoutCache[workoutName] : null;
    if (!ids || ids.length === 0) {
      console.log('GWO: ID non trouvé pour', workoutName, '| cache:', Object.keys(gwoWorkoutCache).length);
      return;
    }
    // Compter combien de lignes avec ce nom ont déjà été injectées
    const alreadyInjected = Array.from(document.querySelectorAll(
      '.gwo-checkbox-cell input[data-workout-name="' + CSS.escape(workoutName) + '"]'
    )).length;
    const workoutId = ids[alreadyInjected] || ids[0];

    // Créer la cellule checkbox
    const td = document.createElement('td');
    td.className = 'gwo-checkbox-cell';
    td.style.cssText = 'width:32px; text-align:center; vertical-align:middle; padding:0 4px;';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.dataset.workoutId = workoutId;
    cb.dataset.workoutName = workoutName;
    cb.style.cssText = `
      width: 16px; height: 16px; cursor: pointer;
      accent-color: #00c9a7; margin: 0;
    `;
    cb.checked = gwoSelectedIds.has(workoutId);
    cb.addEventListener('change', () => {
      if (!workoutId) return; // ignorer si pas d'ID
      if (cb.checked) {
        gwoSelectedIds.add(workoutId);
      } else {
        gwoSelectedIds.delete(workoutId);
      }
      updateDeleteBar();
    });

    td.appendChild(cb);
    row.insertBefore(td, row.firstChild);
  });

  // Injecter aussi la colonne header si pas déjà fait
  const headerRow = Array.from(document.querySelectorAll('tr')).find(r =>
    r.className && r.className.includes('tableHeader')) || document.querySelector('thead tr');
  if (headerRow && !headerRow.querySelector('.gwo-checkbox-header')) {
    const th = document.createElement('th');
    th.className = 'gwo-checkbox-header';
    th.style.cssText = 'width:32px; text-align:center; padding:0 4px;';
    // Checkbox "tout sélectionner"
    const cbAll = document.createElement('input');
    cbAll.type = 'checkbox';
    cbAll.title = 'Tout sélectionner';
    cbAll.style.cssText = 'width:16px; height:16px; cursor:pointer; accent-color:#00c9a7; margin:0;';
    cbAll.addEventListener('change', () => {
      const allCbs = document.querySelectorAll('.gwo-checkbox-cell input[type=checkbox]');
      allCbs.forEach(c => {
        if (!c.dataset.workoutId) return; // ignorer si pas d'ID
        c.checked = cbAll.checked;
        if (cbAll.checked) {
          gwoSelectedIds.add(c.dataset.workoutId);
        } else {
          gwoSelectedIds.delete(c.dataset.workoutId);
        }
      });
      updateDeleteBar();
    });
    th.appendChild(cbAll);
    headerRow.insertBefore(th, headerRow.firstChild);
  }

  updateDeleteBar();
}

function updateDeleteBar() {
  // Nettoyer les éventuels undefined/null dans le Set
  gwoSelectedIds.delete(undefined);
  gwoSelectedIds.delete(null);
  gwoSelectedIds.delete('undefined');
  const count = gwoSelectedIds.size;
  let bar = document.getElementById('gwo-delete-bar');

  if (count === 0) {
    if (bar) bar.remove();
    return;
  }

  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'gwo-delete-bar';
    bar.style.cssText = `
      position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
      background: #1a1d24; border: 1px solid #2d3748; border-radius: 10px;
      padding: 12px 20px; display: flex; align-items: center; gap: 16px;
      z-index: 999999; box-shadow: 0 8px 32px rgba(0,0,0,0.4);
      font-family: 'Segoe UI', sans-serif;
    `;

    const label = document.createElement('span');
    label.id = 'gwo-delete-label';
    label.style.cssText = 'color:#e5e7eb; font-size:13px; font-weight:600;';

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Annuler';
    cancelBtn.style.cssText = `
      background: none; border: 1px solid #4b5563; color: #9ca3af;
      border-radius: 6px; padding: 7px 16px; font-size: 12px;
      font-weight: 600; cursor: pointer; transition: all 0.2s;
    `;
    cancelBtn.addEventListener('click', () => {
      gwoSelectedIds.clear();
      document.querySelectorAll('.gwo-checkbox-cell input, .gwo-checkbox-header input')
        .forEach(c => c.checked = false);
      updateDeleteBar();
    });
    cancelBtn.addEventListener('mouseenter', () => cancelBtn.style.borderColor = '#6b7280');
    cancelBtn.addEventListener('mouseleave', () => cancelBtn.style.borderColor = '#4b5563');

    const deleteBtn = document.createElement('button');
    deleteBtn.id = 'gwo-delete-confirm-btn';
    deleteBtn.style.cssText = `
      background: #ef4444; border: none; color: white;
      border-radius: 6px; padding: 7px 16px; font-size: 12px;
      font-weight: 700; cursor: pointer; letter-spacing: 1px;
      text-transform: uppercase; transition: all 0.2s;
    `;
    deleteBtn.addEventListener('mouseenter', () => deleteBtn.style.opacity = '0.85');
    deleteBtn.addEventListener('mouseleave', () => deleteBtn.style.opacity = '1');
    deleteBtn.addEventListener('click', confirmAndDelete);

    bar.appendChild(label);
    bar.appendChild(cancelBtn);
    bar.appendChild(deleteBtn);
    document.body.appendChild(bar);
  }

  const label = document.getElementById('gwo-delete-label');
  const deleteBtn = document.getElementById('gwo-delete-confirm-btn');
  if (label) label.textContent = `🗑️  ${count} entraînement${count > 1 ? 's' : ''} sélectionné${count > 1 ? 's' : ''}`;
  if (deleteBtn) deleteBtn.textContent = `Supprimer ${count > 1 ? 'les ' + count : ''}`;
}

async function confirmAndDelete() {
  const count = gwoSelectedIds.size;
  if (count === 0) return;

  const ok = confirm(
    `Supprimer ${count} entraînement${count > 1 ? 's' : ''} ?
Cette action est irréversible.`
  );
  if (!ok) return;

  const ids = [...gwoSelectedIds];
  const deleteBtn = document.getElementById('gwo-delete-confirm-btn');
  if (deleteBtn) { deleteBtn.disabled = true; deleteBtn.textContent = 'Suppression...'; }

  // Lire le token CSRF
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content ||
    (window.__garmin?.csrfToken) ||
    document.cookie.match(/connect-csrf-token=([^;]+)/)?.[1] || '';

  let success = 0, errors = 0;
  for (const id of ids) {
    try {
      const resp = await fetch(`https://connect.garmin.com/gc-api/workout-service/workout/${id}`, {
        method: 'DELETE',
        headers: {
          'NK': 'NT',
          'X-app-ver': '5.23.0.33',
          'connect-csrf-token': csrf,
          'x-requested-with': 'XMLHttpRequest'
        },
        credentials: 'include'
      });
      if (resp.ok) { success++; gwoSelectedIds.delete(id); }
      else errors++;
    } catch(e) { errors++; }
  }

  // Retirer les lignes supprimées du DOM
  document.querySelectorAll('.gwo-checkbox-cell input[type=checkbox]').forEach(cb => {
    if (!gwoSelectedIds.has(cb.dataset.workoutId) && ids.includes(cb.dataset.workoutId)) {
      const row = cb.closest('tr');
      if (row) row.remove();
    }
  });

  removeDeleteBar();

  if (errors > 0) {
    alert(`✅ ${success} supprimé(s). ⚠️ ${errors} erreur(s).`);
  }
}

