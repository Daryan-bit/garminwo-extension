'use strict';

// ── Context Menu ───────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'gwo-send-image',
    title: 'Envoyer à GarminWO',
    contexts: ['image'],
  });
  chrome.contextMenus.create({
    id: 'gwo-send-text',
    title: 'Envoyer à GarminWO',
    contexts: ['selection'],
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'gwo-send-image' && info.menuItemId !== 'gwo-send-text') return;

  // ── Cas texte sélectionné ────────────────────────────────────
  if (info.menuItemId === 'gwo-send-text') {
    const text = info.selectionText?.trim();
    if (!text) return;
    await chrome.storage.local.set({
      gwo_pending_text: { text, ts: Date.now() }
    });
    const tabs = await chrome.tabs.query({ url: '*://connect.garmin.com/*workouts*' });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GWO_OPEN_WITH_TEXT' });
    } else {
      chrome.tabs.create({ url: 'https://connect.garmin.com/modern/workouts' });
    }
    return;
  }
  const imgUrl = info.srcUrl;
  if (!imgUrl) return;

  try {
    // Récupérer l'image et la convertir en base64
    const resp = await fetch(imgUrl);
    const blob = await resp.blob();
    const mime = blob.type || 'image/jpeg';
    const buffer = await blob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    const base64 = btoa(binary);

    // Stocker l'image en attente
    await chrome.storage.local.set({
      gwo_pending_image: { base64, mime, ts: Date.now() }
    });

    // Ouvrir ou activer un onglet Garmin Connect Workouts
    const tabs = await chrome.tabs.query({ url: '*://connect.garmin.com/*workouts*' });
    if (tabs.length > 0) {
      // Onglet existant : l'activer et envoyer un message
      await chrome.tabs.update(tabs[0].id, { active: true });
      await chrome.windows.update(tabs[0].windowId, { focused: true });
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GWO_OPEN_WITH_IMAGE' });
    } else {
      // Pas d'onglet Garmin ouvert : en ouvrir un
      chrome.tabs.create({ url: 'https://connect.garmin.com/modern/workouts' });
      // content.js détectera l'image en attente au chargement
    }
  } catch (e) {
    console.error('GarminWO context menu error:', e);
  }
});


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'ANALYZE_IMAGE') {
    const fn = msg.engine === 'gemini' ? analyzeWithGemini : analyzeWithClaude;
    fn(msg.apiKey, msg.imageBase64, msg.imageMime)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(err   => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (msg.type === 'IMPORT_WORKOUT') {
    sendResponse({ success: true });
    return true;
  }
  if (msg.type === 'ANALYZE_TEXT') {
    const fn = msg.engine === 'gemini' ? analyzeTextWithGemini : analyzeTextWithClaude;
    fn(msg.apiKey, msg.text)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(err   => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (msg.type === 'GWO_GET_PENDING') {
    chrome.storage.local.get('gwo_pending_image', (data) => {
      sendResponse({ image: data.gwo_pending_image || null });
      if (data.gwo_pending_image) chrome.storage.local.remove('gwo_pending_image');
    });
    return true;
  }
  if (msg.type === 'GWO_GET_PENDING_TEXT') {
    chrome.storage.local.get('gwo_pending_text', (data) => {
      sendResponse({ text: data.gwo_pending_text?.text || null });
      if (data.gwo_pending_text) chrome.storage.local.remove('gwo_pending_text');
    });
    return true;
  }
});

const PROMPT = `Analyse cette image et identifie toutes les séances running.
Réponds UNIQUEMENT avec un JSON valide sans texte autour :
{"seances":[{"nom":"Nom court","description":"Résumé 1 ligne","steps":[
  {"type":"warmup","condType":"time","cv":"25","cvUnit":"min","t1":"6'00","t2":"6'00","desc":"Footing"},
  {"type":"repeat","iterations":2,"skipLast":true,"steps":[
    {"type":"interval","condType":"distance","cv":"100","cvUnit":"m","t1":"5'00","t2":"5'00"},
    {"type":"recovery","condType":"distance","cv":"100","cvUnit":"m"}
  ]},
  {"type":"cooldown","condType":"lap","desc":"Retour calme"}
]}]}
Types: warmup,interval,recovery,cooldown,repeat.
condType: lap,distance,time. cvUnit: m,km,min,sec.`;

async function analyzeWithClaude(apiKey, imageBase64, imageMime) {
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4096,
      messages: [{ role: 'user', content: [
        { type: 'image', source: { type: 'base64', media_type: imageMime, data: imageBase64 } },
        { type: 'text', text: PROMPT }
      ]}]
    })
  });
  if (!resp.ok) { const e = await resp.json(); throw new Error(e.error?.message || chrome.i18n.getMessage('err_api_anthropic') || 'Anthropic API error'); }
  const data = await resp.json();
  return parseSeances(data.content[0]?.text || '');
}

async function analyzeWithGemini(apiKey, imageBase64, imageMime) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [
        { inline_data: { mime_type: imageMime, data: imageBase64 } },
        { text: PROMPT }
      ]}],
      generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
    })
  });
  if (!resp.ok) { const e = await resp.json(); throw new Error(e.error?.message || chrome.i18n.getMessage('err_api_gemini') || 'Gemini API error'); }
  const data = await resp.json();
  const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
console.log('Gemini raw response:', rawText);
return parseSeances(rawText);
}

function parseSeances(text) {
  // Nettoyer les backticks et markdown
  let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  const match = clean.match(/\{[\s\S]*\}/);
  if (!match) throw new Error(chrome.i18n.getMessage('err_invalid_response') || 'Invalid response');
  // Nettoyer les caractères problématiques
  let json = match[0]
    .replace(/[\u0000-\u001F\u007F]/g, ' ') // caractères de contrôle
    .replace(/,\s*([}\]])/g, '$1')           // virgules trailing
    .replace(/'/g, "'");                      // apostrophes typographiques
  const parsed = JSON.parse(json);
  if (!parsed.seances?.length) throw new Error(chrome.i18n.getMessage('err_no_seance') || 'No session found');
  return parsed;
}
// ── Analyse texte pur (pas d'image) ───────────────────────────
async function analyzeTextWithGemini(apiKey, text) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const prompt = `Voici un plan d'entraînement running en texte. Analyse-le et extrais toutes les séances.
Réponds UNIQUEMENT avec un JSON valide sans texte autour :
{"seances":[{"nom":"Nom court","description":"Résumé 1 ligne","steps":[
  {"type":"warmup","condType":"time","cv":"25","cvUnit":"min","t1":"6'00","t2":"6'00","desc":"Footing"},
  {"type":"repeat","iterations":2,"skipLast":true,"steps":[
    {"type":"interval","condType":"distance","cv":"100","cvUnit":"m","t1":"5'00","t2":"5'00"},
    {"type":"recovery","condType":"distance","cv":"100","cvUnit":"m"}
  ]},
  {"type":"cooldown","condType":"lap","desc":"Retour calme"}
]}]}
Types: warmup,interval,recovery,cooldown,repeat.
condType: lap,distance,time. cvUnit: m,km,min,sec.

Texte à analyser :
${text}`;

  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
    })
  });
  if (!resp.ok) { const e = await resp.json(); throw new Error(e.error?.message || 'Gemini API error'); }
  const data = await resp.json();
  const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
  return parseSeances(rawText);
}

async function analyzeTextWithClaude(apiKey, text) {
  const prompt = `Voici un plan d'entraînement running en texte. Analyse-le et extrais toutes les séances.
Réponds UNIQUEMENT avec un JSON valide sans texte autour :
{"seances":[{"nom":"Nom court","description":"Résumé 1 ligne","steps":[
  {"type":"warmup","condType":"time","cv":"25","cvUnit":"min","t1":"6'00","t2":"6'00","desc":"Footing"},
  {"type":"repeat","iterations":2,"skipLast":true,"steps":[
    {"type":"interval","condType":"distance","cv":"100","cvUnit":"m","t1":"5'00","t2":"5'00"},
    {"type":"recovery","condType":"distance","cv":"100","cvUnit":"m"}
  ]},
  {"type":"cooldown","condType":"lap","desc":"Retour calme"}
]}]}
Types: warmup,interval,recovery,cooldown,repeat.
condType: lap,distance,time. cvUnit: m,km,min,sec.

Texte à analyser :
${text}`;

  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 4096,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  if (!resp.ok) { const e = await resp.json(); throw new Error(e.error?.message || 'Anthropic API error'); }
  const data = await resp.json();
  return parseSeances(data.content[0]?.text || '');
}
